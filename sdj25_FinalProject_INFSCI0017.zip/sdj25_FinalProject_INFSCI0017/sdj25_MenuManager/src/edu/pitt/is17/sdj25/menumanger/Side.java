package edu.pitt.is17.sdj25.menumanger;

/**
 * Class: Side
 * Author: Steve Johnston
 * Created: 2/21/2017
 */

public class Side extends MenuItem {

	public Side(String name, String desc, int cal, double price) {
		super(name, desc, cal, price);
	}
	
}

package edu.pitt.is17.sdj25.menumanger;

/**
 * Class: Beer
 * Author: Steve Johnston
 * Created: 2/21/2017
 */

public class Beer extends MenuItem {

	public Beer(String name, String desc, int cal, double price) {
		super(name, desc, cal, price);
	}
	
}

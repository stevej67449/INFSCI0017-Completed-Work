package edu.pitt.is17.sdj25.menumanger;

/**
 * Class: Appetizer
 * Author: Steve Johnston
 * Created: 2/21/2017
 */

public class Appetizer extends MenuItem {

	public Appetizer(String name, String desc, int cal, double price) {
		super(name, desc, cal, price);
	}

}
